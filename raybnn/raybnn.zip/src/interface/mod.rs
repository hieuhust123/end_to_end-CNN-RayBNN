



pub mod autotransfer_f32;

pub mod automatic_f32;

pub mod autotrain_f32;

pub mod autotest_f32;








pub mod autotransfer_f64;

pub mod automatic_f64;

pub mod autotrain_f64;

pub mod autotest_f64;




