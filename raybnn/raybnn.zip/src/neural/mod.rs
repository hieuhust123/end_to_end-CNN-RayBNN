

pub mod network_f64;
pub mod activation_f64;
pub mod weight_share_f64;
pub mod restructure_f64;



pub mod network_f32;
pub mod activation_f32;
pub mod weight_share_f32;
pub mod restructure_f32;
